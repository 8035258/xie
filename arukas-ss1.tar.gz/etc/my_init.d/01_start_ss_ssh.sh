#!/bin/bash

# Enable SSH
rm -rf /etc/service/sshd

# Start web server
env | grep -E '^MARATHON_HOST=|MARATHON_PORT_' > /home/wwwroot/default/marathon.conf
if [ "x$MARATHON_HOST" != "x" ]; then
	getent hosts $MARATHON_HOST | awk '{print "MARATHON_HOST_IP="$1; exit;}' >> /home/wwwroot/default/marathon.conf
fi

start-stop-daemon -S -b -n tmp-httpd -d /home/wwwroot/default -x /usr/bin/python3 -- -m http.server 80

start-stop-daemon -n  /usr/local/shadowsocks/config.json python3 -d start

cd /usr/local/shadowsocks

exec python3 server.py -c /etc/shadowsocks/ssr.json
