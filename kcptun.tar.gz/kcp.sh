#!/bin/bash

# Start ShadowSocks
env | grep '^SHADOWSOCKS_CFGS_' | awk -F '=' '{print $1;}' | while read T_NAME; do
	SS_NAME="${T_NAME:17}"
	echo "${!T_NAME}" > /xie-master/shadowsocks/${SS_NAME}.json
	python server.py -c /xie-master/shadowsocks/${SS_NAME}.json -d start
done

# Start ShadowSocks
cd /root/kcptun/
./server_linux_amd64 -c /root/kcptun/server-config.json 2>&1 &
echo "Kcptun started."

chmod +x /root/kcptun/*.sh

sh /root/kcptun/start.sh
